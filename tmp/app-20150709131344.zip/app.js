(function() {

  return {
    events: {
      'app.activated':    'onActivated',
      'app.deactivated':  'onDestroyed',
      'app.created':      'onCreated',
      'app.willDestroy':  'onDestroyed',

      'iframe.roger':'onConnected',

      'click .ping_all':'pingAll',
      'notification.pingAll':'receivedPing'

    },
    requests: {
      agent: function(data) {
        return {
          url: this.firebase +'/agents/'+data.agent+'.json',
          type: 'PATCH',
          contentType: 'JSON',
          data: JSON.stringify({
            date: data.date,
            id: data.agent
          })
        };
      },
      ticket: function(data) {
        return {
          url: this.firebase + '/agents/'+data.agent+'/tickets/'+data.ticket+'.json',
          type: 'PUT',
          contentType: 'JSON',
          data: JSON.stringify({
            date: data.date,
            action: data.action,
            id: data.ticket
          })
        };
      },
      destroyTicket: function(data) {
        return {
          url: this.firebase + '/agents/'+data.agent+'/tickets/'+data.ticket+'.json',
          type: 'DELETE'
        };
      },


      user: function(data) {
        return {
          url: this.firebase + '/agents/'+data.agent+'/users/'+data.user+'.json',
          type: 'PUT',
          contentType: 'application/JSON',
          data: JSON.stringify({
            date: data.date,
            action: data.action,
            id: data.user
          })
        };
      },


      pingAll: function() {
        return {
          url: '/api/v2/apps/notify.json',
          type: 'POST',
          contentType: 'application/JSON',
          data: JSON.stringify({
            app_id: this.id(),
            event: 'pingAll'
          })
        };
      }
    },

    onActivated: function(e) {
      this.log('foreground');
    },
    // onDeactivated: function() {
    //   this.log('background');
    // },
    onCreated: function() {
      this.log('created');
    },
    onDestroyed: function(e) {
      // this.log('not present');
      console.dir(e);
      var data = {
        agent: this.currentUser().id(),
        ticket: this.ticket().id() || 'new'
      };
      this.ajax('destroyTicket', data)
      .done(function(response) {

      });
        
    },
    log: function(action) {
      this.firebase = 'https://theeyeofzen.firebaseio.com/accounts/'+ this.currentAccount().subdomain();
      var location = this.currentLocation();
      var data;
      var date = Date.now();

      // if ticket_sidebar
      if(location == 'ticket_sidebar' || location == 'new_ticket_sidebar') {
        this.hide();
        data = {
          agent: this.currentUser().id(),
          ticket: this.ticket().id() || 'new',
          date: date,
          action: action
        };
        this.ajax('ticket', data);

      }
      // if new_ticket_sidebar
      // if(location == 'new_ticket_sidebar') {
      //   this.hide();
      //   data = {
      //     agent: this.currentUser().id(),
      //     ticket: 'new',
      //     date: date,
      //     action: action
      //   };
      //   this.ajax('ticket', data);
      // }

      // if user_sidebar
      if(location == 'user_sidebar') {
        this.hide();
        data = {
          agent: this.currentUser().id(),
          user: this.user().id(),
          date: date,
          action: action
        };
        this.ajax('user', data);
      }

      // if nav_bar
      if(location == 'nav_bar') {
        // TODO??? track agent/admin bootstrapping of Lotus???
        // data = {
        //   agent: this.currentUser().id(),
        //   date: date
        // };
        // this.ajax('agent', data);


        // if Admin -> show template
        if(this.currentUser().role() == 'admin') {
          this.switchTo('iframe', {

          });
        } else {
          this.hide();
        }
      }
    },

    // messages
    onConnected: function(data) {
      services.notify("The Eye of Zen sees all. Use it wisely.");
    },
    getUsers: function(roles) {
      // fetch users with the given roles
    },
    pingAll: function() {

      this.ajax('pingAll').done(function(response) {
        services.notify('Sent ping. Now come the pongs.');
      });
    },
    receivedPing: function(data) {
      var loc = this.currentLocation();
      console.log(loc);
      if(loc == 'ticket_sidebar' || loc == 'new_ticket_sidebar' || loc == 'user_sidebar') {
        console.log('location matches');
        console.dir(this.currentUser().isIdle());
        if( !this.currentUser().isIdle() ) {
          this.log('active');
          console.log('user is active');
        } else {
          // this.onDestroyed();
        }
      }
    },

    _location: function() {
      return; // TODO send the current location
    }
  };

}());
